
from isaac import *

from navigation_system import NavigationSystem

class SendcorPython(Codelet):
    def start(self):
        self.navigation_system = NavigationSystem()
        self.tx = self.isaac_proto_tx("Vector2dProto", "odometry")
        self.tick_periodically(1.0)

    def tick(self):
        #print("tick")

        lat, lon = self.navigation_system.get_gps()
        #print(self.navigation_system.get_gps())
        tx_message = self.tx.init()
        tx_message.proto.x = 123.03
        tx_message.proto.y = 223.02
        self.tx.publish()

class PingPython(Codelet):
    def start(self):
        self.rx = self.isaac_proto_rx("Vector2dProto", "odometry")
        #self.tick_periodically(1.0)
        self.tick_on_message(self.rx)

    def tick(self):
        print("-!!!!!received!!!!!!!")
        rx_message = self.rx.message
        received = rx_message.proto
        #print(rx_message.proto)
        print('x=', received.x)
        print('y=', received.y)
        print("----------")


def main():
    app = Application(app_filename="apps/tutorials/ping_python/ping_python.app.json")

    app.load_module("sight")
    app.nodes["ping_node"].add(name='PingPython', ctype=PingPython)
    app.nodes["sendcor_node"].add(name='SendcorPython', ctype=SendcorPython)
    app.connect('sendcor_node/SendcorPython', 'odometry',
                'ping_node/PingPython', 'odometry')


    app.run()


if __name__ == '__main__':
    main()
